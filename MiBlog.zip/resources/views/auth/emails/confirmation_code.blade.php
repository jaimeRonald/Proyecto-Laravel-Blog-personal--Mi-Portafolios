<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>

	<p>porfabor confirma tu correo electronico</p>
	<a href="{{ url('register/verify/'.$confirmation_code)}}">
		clic para confirmar correo electronico
	</a>

</body>
</html>