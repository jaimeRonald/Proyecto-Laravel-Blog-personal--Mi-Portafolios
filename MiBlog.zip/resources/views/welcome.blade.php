<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->

        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
           
        </style>
        
    </head>
<body>

@extends('layouts.app')


@section('content')
 @endsection

@section('article')
  
  <div class="mt-md-m5">
       <div class="container">

         

         <div class="row">
            @foreach($sql_foros as $fo)
            <div class="col-xl-6 col-md-6 mb-3">
                  
                <div class="card1" style="width:">
 
                  <img class="card-img-top" src="../images/{{$fo->rutafoto}}" alt="Card image cap">
                  <div class="card-header">
                    <h1><a href="{{route('Categoria.edit',$fo->id)}}">{{$fo->titulo}}</a></h1>
                   </div>
                  <div class="card-body">
                    <p class="card-text">{{$fo->descripcion}}</p>
                 </div>
                 
                </div>
            
           
          </div>

          @endforeach    
          
        </div>
          
   
    </div>
  </div>
  
      <div class="row">
         <div class="col-5">
             
         </div> 
      
       <div class="col">
       <nav aria-label="Page navigation example" >
          <p class="text-primary">Mas resultados</p>
          <ul class="pagination" >
            <li class="page-item  {{$_GET['pagina']<=1?'disabled':''}}">
                <a class="page-link" href="dia?pagina={{$_GET['pagina']-1}}">Previous</a></li>

            @for($i=0;$i<$can_de_paginas;$i++)
            <li class="page-item  {{$_GET['pagina']==$i+1?'active':''}}"><a class="page-link" href="dia?pagina={{$i+1}}">{{$i+1}}</a></li>
            @endfor


            <li class="page-item {{$_GET['pagina']>=$can_de_paginas?'disabled':''}}">
                <a class="page-link" href="dia?pagina={{$_GET['pagina']+1}}">Next</a></li>
        </ul>
    </nav>
    </div>
    </div>
@endsection
</body>

    @section('footer')
    

    @endsection

</html>
