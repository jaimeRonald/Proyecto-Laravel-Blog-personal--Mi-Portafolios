<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>


      





   

    <?php $__env->startSection('content'); ?>
    <?php $__env->stopSection(); ?>
    

    <?php $__env->startSection('article'); ?>


    <div class="container">
       

        
         <div class="row">
            <?php $__currentLoopData = $foroLike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-6 col-md-6 mb-3">
                  
                <div class="card1" style="width:">
 
                  <img class="card-img-top" src="../../images/<?php echo e($fo->rutafoto); ?>" alt="Card image cap">
                  <div class="card-header">

                    <h1><a  href="<?php echo e(route('Categoria.edit',$fo->id)); ?>"><?php echo e($fo->titulo); ?></a></h1>
                   </div>
                  <div class="card-body">
                    <p class="card-text"><?php echo e($fo->descripcion); ?></p>
                 </div>
                 
                </div>
            
           
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
          
        </div>
          
   
    </div>
     

     
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('aside'); ?>

  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('footer'); ?>
  <div class="container"></div>
  <?php $__env->stopSection(); ?>

	
 
   


 
</body>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/MiBlog/resources/views/admin/foro/listaForos.blade.php ENDPATH**/ ?>