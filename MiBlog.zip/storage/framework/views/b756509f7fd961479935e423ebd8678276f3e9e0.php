<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body background="#FFFFCC">


   ;

   <?php $__env->startSection('cabecera'); ?>


   <?php echo Form::open(['method' => 'POST','action'=>'AdminUserController@store','files'=>true]); ?>

   <table border="1" align="center">

    <tr>
        <td><?php echo Form::label('name', 'Nombre: '); ?></td>
        <td><?php echo Form::text('name',null,['class' => 'form-control','placeholder'=>'Nombres'] ); ?></td>
    </tr>

    <tr>
        <td><?php echo Form::label('password', 'Contraseña: '); ?></td>
        <td><?php echo Form::text('password',null, ['class'=>'form-control','placeholder'=>'contraseña']); ?></td>
    </tr>

    <tr>
        <td><?php echo Form::label('email', 'Email: '); ?></td>
        <td><?php echo Form::text('email',null,['class'=>'form-control','placeholder'=>'email'],); ?></td>
    </tr>
    <tr>
        <td><?php echo Form::label('role_id', 'Rol : '); ?></td>
        <td><?php echo Form::text('role_id'); ?></td>
    </tr>

    <tr>
        <td><?php echo form::label('foto','foto_id'); ?></td>
        <td><?php echo form::file('foto_id'); ?></td>
    </tr>
    <tr>
        <td><?php echo form::submit('Crear usuario'); ?></td>

        <td><?php echo form::reset('Borrar'); ?>

              
        </td>
        
    </tr>
    
 
   

</table>



<?php echo Form::close(); ?>


<?php if(count($errors)>0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e(" faltan llenar campos "); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php endif; ?>
<?php $__env->stopSection(); ?>





</body>
</html>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/MiBlog/resources/views/admin/users/create.blade.php ENDPATH**/ ?>