<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/MiBlog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>