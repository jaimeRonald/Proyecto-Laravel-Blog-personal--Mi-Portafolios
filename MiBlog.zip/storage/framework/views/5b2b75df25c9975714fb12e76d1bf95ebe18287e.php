<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  

 





  <nav  class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand text-white">
        <img  src="../images/compu2.png">
  </a>
   
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
       <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sobre Mi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Java</a>
          <a class="dropdown-item" href="#">PHP</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">MySql</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Califica</a>
      </li>
    </ul>
    <form class="form-inline">
          <input class="form-control mr-sm-6" >
          <button class="btn btn-success">Buscar</button>
        </form>
  </div>
</nav>
    
            
  </div>
</body>
</html><?php /**PATH /home/vagrant/code/MiBlog/resources/views/layouts/nabar.blade.php ENDPATH**/ ?>