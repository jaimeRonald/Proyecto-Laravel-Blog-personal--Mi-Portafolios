<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>


      





   

    <?php $__env->startSection('content'); ?>
    <?php $__env->stopSection(); ?>
    

    <?php $__env->startSection('article'); ?>
    <div class="container" >

     <!-- CUANDO SI SE ENCONTRO FORO  -->
      <?php if(isset($foros)): ?>

     

      <h2 class="card-title"><?php echo e($foros->titulo); ?></h2>
      
 
      <a href="#" class="card-link">Deja un comentario</a><br>
      <h9><?php echo e($foros->created_at); ?></h9><br>
       <p><?php echo e($foros->descripcion); ?></p>
       <img style="width: 400px;height: 400px"  src="../../images/<?php echo e($foros->rutafoto); ?>"  >
      <p><?php echo $foros->contenido;?></p> 
       <img   style="width: 400px;height: 400px"  src="../../images/<?php echo e($foros->ruta_imagenes); ?>" ><br><br>
      
      
      

      <br><br><br>
      <p>Comentarios</p>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <table  class="table table-bordered">
        <tr>
          <th><?php echo e($val->name); ?></th>
          <th><?php echo e($val->created_at); ?></th>
        </tr>
        <tr>
          <td colspan="2"><?php echo e($val->mensaje); ?></td>
        </tr>

      </table>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      


      <?php if(auth()->guard()->guest()): ?>
      <?php // NO SE HA LOGEADO ?>
      <form role="form" action="<?php echo e(route('login')); ?>" method="GET">
        <div class="form-group">
          <span class="label label-success" >Ingresa tu comentario</span>
          <input type="text" class="form-control" id="comentario" value="Registrate para dejar tu comentario" readonly> 
        </div>
        <button type="submit" class="btn btn-primary">Regitrarse</button>
      </form>
     <br><br>
      <?php //SI SE HA LOGEADO ?>
      <?php else: ?> 

      <form  method="POST"  action="<?php echo e(url('mensaje')); ?>"  accept-charset="UTF-8">



        <div class="form-group">
          <span class="label label-success">Ingresa tu comentario</span>
          <input type="text" class="form-control" id="comentario" name="comentario">
          <input type="hidden" class="form-control" id="comentario" name="foro" value="<?php echo e($foros->id); ?>" >
          <input type="hidden" class="form-control" id="comentario" name="usuario" value="<?php echo e(Auth::user()->id); ?>" >
          <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
        </div>


        <button type="submit" class="btn btn-primary" >Comentar</button>
      <br>
      </form>

      <?php endif; ?>

  </div>
    <!-- CUANDO NO ENCONTRO NUNGUN FORO  -->
   <?php else: ?>
        <P><?php echo e($NingunResultado); ?></P>
   <?php endif; ?>
<?php $__env->stopSection(); ?>

  <?php $__env->startSection('aside'); ?>

  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('footer'); ?>
  <div class="container"></div>
  <?php $__env->stopSection(); ?>

	
 
   


 
</body>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/MiBlog/resources/views/admin/foro/foro.blade.php ENDPATH**/ ?>